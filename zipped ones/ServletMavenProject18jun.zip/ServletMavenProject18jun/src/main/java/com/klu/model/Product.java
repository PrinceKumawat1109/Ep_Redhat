package com.klu.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Product {
  //vars
  private int pid;
  private String pname;
  private double price;
  public int getPid() {
    return pid;
  }
  public void setPid(int pid) {
    this.pid = pid;
  }
  public String getPname() {
    return pname;
  }
  public void setPname(String pname) {
    this.pname = pname;
  }
  public double getPrice() {
    return price;
  }
  public void setPrice(double price) {
    this.price = price;
  }
  public void setStoreData(String x)throws Exception {
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "@Mvssprem7");
    String vsql = "insert into product values(?,?,?)";
    PreparedStatement pstmt = con.prepareStatement(vsql);
    pstmt.setInt(1, pid);
    pstmt.setString(2, pname);
    pstmt.setDouble(3, price);
    pstmt.executeUpdate();
  }
}