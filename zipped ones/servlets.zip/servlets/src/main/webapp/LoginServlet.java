package main.webapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet{
  //vars
  Connection con;
  PreparedStatement pstmt;
  ResultSet rs;
  
  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();
    //capture the details from login form
    String uname = req.getParameter("uname");
    String pwd = req.getParameter("pwd");
    
    //validation
    if( uname.equals("") || uname == null ) {
      out.println("<h3 align='center'>Uname/Password Can't Be Empty</h3><br>");
      req.getRequestDispatcher("/index.html").include(req, resp);
    }else {
      try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
        String vsql = "select * from userdetails where uname=? and password=?";
        pstmt = con.prepareStatement(vsql);
        pstmt.setString(1, uname);
        pstmt.setString(2, pwd);
        rs = pstmt.executeQuery();
        out.println("<h2 align='center'>");
        if( rs.next() ) {
          //forward the request along with uname to another resource(WelcomeServlet)
          //storing uname value into request object
          req.setAttribute("x", uname);
          req.getRequestDispatcher("/welcome").forward(req, resp);
        }else {
          out.println("Invalid Credentials<br>");
          out.println("Login Again");
          req.getRequestDispatcher("/index.html").include(req, resp);
        }
        out.println("</h2>");
      }catch(Exception e) {
        e.printStackTrace();
      }
    }  
  }
}
