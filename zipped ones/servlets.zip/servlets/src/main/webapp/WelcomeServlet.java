package main.webapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WelcomeServlet extends HttpServlet{
  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    //capture the uname value from req object
    resp.setContentType("text/html");
    PrintWriter out =resp.getWriter();
    
    String uname = (String)req.getAttribute("x");
    out.println("<h2 align='center'");
    out.println("Login Success.<br>");
    out.println("Welcome to :" + uname);
    out.println("</h2>");
  }
}