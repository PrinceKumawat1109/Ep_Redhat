package main.webapp;

import javax.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InsertStudentData extends HttpServlet{
	  //vars
	  Connection con;
	  PreparedStatement pstmt;
	  
	  @Override
	  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    //set the content type
	    resp.setContentType("text/html");
	    //get the PrintWriter object
	    PrintWriter out = resp.getWriter();
	    //capture the details coming from client
	    int sid = Integer.parseInt(req.getParameter("sid"));
	    String sname = req.getParameter("sname");
	    String course = req.getParameter("course");
	    
	    try {
	      //get the connection for mysql
	      Class.forName("com.mysql.cj.jdbc.Driver");
	      con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb2","root","mvak78925");
	      String vsql = "insert into student1 values(?,?,?)";
	      pstmt = con.prepareStatement(vsql);
	      pstmt.setInt(1, sid);
	      pstmt.setString(2, sname);
	      pstmt.setString(3, course);
	      //execute the query
	      int n = pstmt.executeUpdate();
	      if( n > 0 )
	        out.println("<h3 align='center'>Data Stored Successfully</h3");
	      con.close();
	    }catch(Exception e) {
	      e.printStackTrace();
	    }
	  }
	}