// Code for Transaction Management (Commit and RollBack)


package one.jdbctransaction;

import java.sql.*;
import java.util.Scanner;

public class App 
{
    public static void main( String[] args ) throws Exception
    {
        Connection con = null;
        
        try
        {
          con = DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Momdadlove@04");
          Statement s =con.createStatement();
          con.setAutoCommit(false);
          Scanner scanner = new Scanner(System.in);
          System.out.println("Enter the Account No to debit:");
          int fromacc = scanner.nextInt();
          System.out.println("Enter the Amount:");
          int amt = scanner.nextInt();
          System.out.println("Enter the Account No to credit:");
          int toacc = scanner.nextInt();
          String qry = "select count(*) from banking where accno="+toacc;
          ResultSet rs = s.executeQuery(qry);
          int status = 0;
          while(rs.next()) 
          {
            status = rs.getInt(1);
          }
          
          s.executeUpdate("update banking set balance=(balance-"+amt+") where accno="+fromacc);
          if(status==1)
          {
            s.executeUpdate("update banking set balance=(balance+"+amt+") where accno="+toacc);
            
          }
          else
          {
            throw new Exception("Invalid Account Number.Transection roll back");
            
          }
          con.commit();
          System.out.println("Transaction Commited..");
          con.close();
          
        }
        catch(Exception e)
        {
          con.rollback();
          System.out.println(e.getMessage());
        }
      
      
    }
}