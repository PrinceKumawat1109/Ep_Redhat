package one.jdbc_callablestatement;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class App 
{
    public static void main( String[] args ) throws Exception
    {
        
      String url = "jdbc:mysql://localhost:3306/klu";
      String username = "root";
      String psw = "Momdadlove@04";
      Connection con = DriverManager.getConnection(url,username,psw);
      
      CallableStatement stmt = con.prepareCall("{CALL get_details()}");
      
      ResultSet rs =stmt.executeQuery();
      
      while(rs.next())
      {
    	  System.out.println(rs.getInt(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3));
    	  
      }
      con.close();
    }
}