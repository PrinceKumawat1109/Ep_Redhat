package one.jdbc_callablestatement;

import java.sql.*;

public class InParamDemo {
	
	public static void main(String[] args) throws Exception 
	{
		Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Momdadlove@04");
		
		CallableStatement stmt = con.prepareCall("{Call get_detailsByEmpID(?)}");
				
	    stmt.setInt(1, 100);
		
		ResultSet rs = stmt.executeQuery();
		
		   while(rs.next())
		      {
		    	  System.out.println(rs.getInt(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3));
		    	  
		      }
		      con.close();
		    }
		
	}
