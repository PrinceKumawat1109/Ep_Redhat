package one.jdbc_crud;

import java.sql.*;

public class App 
{
    public static void main( String[] args )throws Exception
    {
      String url="jdbc:mysql://localhost:3306/klu";
      String username="root";
      String psswd="Momdadlove@04";
      Connection con = DriverManager.getConnection(url,username,psswd);
      Statement stmt = con.createStatement();
      //ResultSet rs = stmt.executeQuery("select * from student1");
      //String qry="insert into student1 values(31124, 'jaswanth')";
      //String qry="update student1 set name='kumble' where id=31326";
      String qry="delete from student where rollno=100";
      stmt.executeUpdate(qry);
      /*while(rs.next())
      {
        System.out.println( "Roll Number: "+rs.getInt(1));
        System.out.println( "Name: "+rs.getString(2));
      }*/
        con.close();
        System.out.println("Done");
    }
}