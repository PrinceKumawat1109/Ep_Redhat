package one.jdbc_callablestatement;

import java.sql.*;

public class OutParamDemo {
	
	public static void main(String[] args) throws Exception 
	{
		Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Momdadlove@04");
		
		CallableStatement stmt = con.prepareCall("{Call get_detailsByOutParam(?)}");
				
	    stmt.registerOutParameter(1,Types.INTEGER);
		
		stmt.execute();
		
		int cnt =stmt.getInt(1);
		
		System.out.println("no of rows present in employee table: "+ cnt );
		
		  
		      con.close();
		    }
		
	}

