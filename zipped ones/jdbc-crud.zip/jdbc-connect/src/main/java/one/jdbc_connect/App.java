package one.jdbc_connect;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class App 
{
    public static void main( String[] args ) throws Exception
    {
        
      String url = "jdbc:mysql://localhost:3306/klu";
      String username = "root";
      String psw = "Momdadlove@04";
      Connection con = DriverManager.getConnection(url,username,psw);
      Statement stmt =con.createStatement();
      ResultSet rs = stmt.executeQuery("select * from student");
      while(rs.next())
      {
        System.out.println( "Roll No:" + rs.getInt(1) );
        System.out.println( "Name:" + rs.getString(2) );
      }
      con.close();
      
      
    }
}