// prepared statement
// both 
/*package one.jdbcps;

import java.sql.*;

public class App 
{
    public static void main( String[] args ) throws Exception
    {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Momdadlove@04");
        String qry = "insert into employee values(?,?,?)";
        PreparedStatement stmt = con.prepareStatement(qry);
        stmt.setInt(1, 10001);
        stmt.setString(2, "xxxx");
        stmt.setString(3, "hyderabad");
        stmt.executeUpdate();
          
      
      System.out.println( "Row Inserted...." );
      con.close();
    }
    
}*/

package one.jdbcps;

import java.sql.*;

public class App 
{
    public static void main( String[] args ) throws Exception
    {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Momdadlove@04");
        String qry = "update employee set name=? where empid=102";
        PreparedStatement stmt = con.prepareStatement(qry);
        stmt.setString(1, "deemed to be university");
        stmt.executeUpdate();
          
      
      System.out.println( "Row Inserted...." );
      con.close();
    }
    
}